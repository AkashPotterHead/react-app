
//import './App.css';
import NasaPhoto from './nasa/nasa'
import "react-datepicker/dist/react-datepicker.css";

function App() {
  return (
    <div>
    <NasaPhoto/>
  </div>
  );
}

export default App;
